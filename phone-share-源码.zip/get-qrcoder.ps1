﻿# 从 NuGet 下载 QRCoder 并提取 .NET Framework 4.0 版本
# 用法: .\get-qrcoder.ps1 -OutFile .\build\QRCoder.dll

param(
    [Parameter(Mandatory = $true)]
    [string]$OutFile
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$indexUrl = "https://api.nuget.org/v3-flatcontainer/qrcoder/index.json"
$index = Invoke-RestMethod -Uri $indexUrl -UseBasicParsing
$version = $index.versions[-1]
Write-Host "QRCoder 最新版本: $version" -ForegroundColor Cyan

$pkgUrl = "https://api.nuget.org/v3-flatcontainer/qrcoder/$version/qrcoder.$version.nupkg"
$tmp = Join-Path $env:TEMP "qrcoder.$version.nupkg"
Invoke-WebRequest -Uri $pkgUrl -OutFile $tmp -UseBasicParsing

Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead($tmp)
try {
    $entry = $zip.Entries | Where-Object { $_.FullName -eq "lib/net40/QRCoder.dll" } | Select-Object -First 1
    if (-not $entry) {
        $entry = $zip.Entries | Where-Object { $_.FullName -eq "lib/netstandard2.0/QRCoder.dll" } | Select-Object -First 1
    }
    if (-not $entry) { throw "压缩包中没有找到 QRCoder.dll" }

    $dir = Split-Path -Parent $OutFile
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

    [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $OutFile, $true)
}
finally {
    $zip.Dispose()
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
}

Write-Host "已提取: $OutFile" -ForegroundColor Green
