﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using QRCoder;

static class Program
{
    static Mutex instanceMutex;

    [STAThread]
    static void Main()
    {
        // 单实例：重复双击时把已开着的窗口叫到前面，而不是再开一个占不到端口的窗口
        bool createdNew;
        instanceMutex = new Mutex(true, @"Local\PhoneUpload_8080_SingleInstance", out createdNew);
        if (!createdNew)
        {
            ActivateRunning();
            return;
        }

        AppDomain.CurrentDomain.AssemblyResolve += ResolveQRCoder;
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        try { Run(); }
        finally { try { instanceMutex.ReleaseMutex(); } catch { } }
    }

    [DllImport("user32.dll")]
    static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    static void ActivateRunning()
    {
        try
        {
            Process self = Process.GetCurrentProcess();
            foreach (Process p in Process.GetProcessesByName(self.ProcessName))
            {
                if (p.Id == self.Id) continue;
                IntPtr h = p.MainWindowHandle;
                if (h == IntPtr.Zero) continue;
                ShowWindow(h, 9);          // SW_RESTORE
                SetForegroundWindow(h);
                return;
            }
        }
        catch { }
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    static void Run()
    {
        Application.Run(new MainForm());
    }

    static Assembly ResolveQRCoder(object sender, ResolveEventArgs args)
    {
        if (!args.Name.StartsWith("QRCoder", StringComparison.OrdinalIgnoreCase)) return null;
        Assembly self = Assembly.GetExecutingAssembly();

        Stream gz = self.GetManifestResourceStream("QRCoder.dll.gz");
        if (gz != null)
        {
            using (gz)
            using (GZipStream inflate = new GZipStream(gz, CompressionMode.Decompress))
            using (MemoryStream ms = new MemoryStream())
            {
                byte[] buf = new byte[81920];
                int n;
                while ((n = inflate.Read(buf, 0, buf.Length)) > 0) ms.Write(buf, 0, n);
                return Assembly.Load(ms.ToArray());
            }
        }

        Stream plain = self.GetManifestResourceStream("QRCoder.dll");
        if (plain == null) return null;
        using (plain)
        using (MemoryStream ms2 = new MemoryStream())
        {
            byte[] buf2 = new byte[81920];
            int n2;
            while ((n2 = plain.Read(buf2, 0, buf2.Length)) > 0) ms2.Write(buf2, 0, n2);
            return Assembly.Load(ms2.ToArray());
        }
    }
}

class MainForm : Form
{
    const int Port = 8080;
    string saveDir = @"F:\Share\手机上传";

    static readonly SolidBrush BText = new SolidBrush(Color.FromArgb(233, 238, 251));
    static readonly SolidBrush BDim = new SolidBrush(Color.FromArgb(135, 148, 170));
    static readonly SolidBrush BAccent = new SolidBrush(Color.FromArgb(159, 212, 255));
    static readonly SolidBrush BDark = new SolidBrush(Color.FromArgb(6, 18, 31));
    static readonly SolidBrush BWhite = new SolidBrush(Color.White);

    TcpListener listener;
    Bitmap qr;
    byte[] qrPng;
    string page;
    float scale = 1f;

    string ip;
    string url;

    int fileCount;
    long totalBytes;
    string lastName = "";
    string toast = "";
    DateTime toastUntil = DateTime.MinValue;

    RectangleF btnOpen;
    RectangleF btnDir;
    RectangleF btnIp;
    RectangleF urlRect;
    System.Windows.Forms.Timer uiTimer;

    public MainForm()
    {
        Text = "手机传文件 · 关闭窗口即停止服务";
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(9, 14, 26);
        DoubleBuffered = true;
        AutoScaleMode = AutoScaleMode.None;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

        using (Graphics g = Graphics.FromHwnd(IntPtr.Zero)) scale = g.DpiX / 96f;
        ClientSize = new Size(Px(420), Px(600));

        page = LoadPage();
        ip = ChooseIp();
        ApplyIp();
        saveDir = ChooseDir();

        try { Directory.CreateDirectory(saveDir); } catch { }

        try
        {
            listener = new TcpListener(IPAddress.Any, Port);
            listener.Start();
            Thread t = new Thread(AcceptLoop) { IsBackground = true };
            t.Start();
        }
        catch (Exception ex)
        {
            MessageBox.Show("启动失败：" + ex.Message + "\r\n\r\n端口 8080 可能已被占用（是不是已经开着一个窗口了？）",
                "手机传文件", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            Environment.Exit(1);
        }

        uiTimer = new System.Windows.Forms.Timer { Interval = 400 };
        uiTimer.Tick += delegate
        {
            if (toast.Length > 0 && DateTime.Now > toastUntil) { toast = ""; Invalidate(); }
        };
        uiTimer.Start();
    }

    int Px(float v) { return (int)Math.Round(v * scale); }

    // ---------------- IP 与二维码 ----------------

    // 配置放到 %APPDATA%\手机传文件\config.ini，不再往 exe 所在目录（桌面）丢文件
    static string IniPath
    {
        get
        {
            string dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "手机传文件");
            try { Directory.CreateDirectory(dir); } catch { }
            return Path.Combine(dir, "config.ini");
        }
    }

    static bool legacyIniChecked;

    // 老版本把配置写在 exe 旁边，这里迁移一次并删掉旧文件
    static void MigrateLegacyIni()
    {
        if (legacyIniChecked) return;
        legacyIniChecked = true;
        try
        {
            string legacy = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "手机传文件.ini");
            if (!File.Exists(legacy)) return;
            if (!File.Exists(IniPath)) File.Copy(legacy, IniPath, true);
            try { File.Delete(legacy); } catch { }
        }
        catch { }
    }

    static string ReadIni(string key, string fallback)
    {
        MigrateLegacyIni();
        try
        {
            if (!File.Exists(IniPath)) return fallback;
            foreach (string line in File.ReadAllLines(IniPath))
            {
                string s = line.Trim();
                if (s.StartsWith(key + "=", StringComparison.OrdinalIgnoreCase))
                {
                    string v = s.Substring(key.Length + 1).Trim();
                    return v.Length > 0 ? v : fallback;
                }
            }
        }
        catch { }
        return fallback;
    }

    static void WriteIni(string key, string value)
    {
        MigrateLegacyIni();
        try
        {
            List<string> lines = new List<string>();
            bool replaced = false;
            if (File.Exists(IniPath))
            {
                foreach (string line in File.ReadAllLines(IniPath))
                {
                    string s = line.Trim();
                    if (s.Length == 0) continue;
                    if (s.StartsWith(key + "=", StringComparison.OrdinalIgnoreCase))
                    {
                        lines.Add(key + "=" + value);
                        replaced = true;
                    }
                    else
                    {
                        lines.Add(s);
                    }
                }
            }
            if (!replaced) lines.Add(key + "=" + value);
            File.WriteAllLines(IniPath, lines.ToArray(), new UTF8Encoding(false));
        }
        catch { }
    }

    static List<string> LocalIps()
    {
        List<string> list = new List<string>();
        try
        {
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.OperationalStatus != OperationalStatus.Up) continue;
                if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                foreach (UnicastIPAddressInformation ua in ni.GetIPProperties().UnicastAddresses)
                {
                    if (ua.Address.AddressFamily != AddressFamily.InterNetwork) continue;
                    string s = ua.Address.ToString();
                    if (s.StartsWith("169.254.")) continue;
                    if (!list.Contains(s)) list.Add(s);
                }
            }
        }
        catch { }
        list.Sort(delegate(string a, string b)
        {
            int pa = a.StartsWith("192.168.") ? 0 : (a.StartsWith("10.") ? 1 : 2);
            int pb = b.StartsWith("192.168.") ? 0 : (b.StartsWith("10.") ? 1 : 2);
            if (pa != pb) return pa - pb;
            return string.Compare(a, b);
        });
        return list;
    }

    static bool ValidIp(string s)
    {
        IPAddress a;
        return IPAddress.TryParse(s, out a) && a.AddressFamily == AddressFamily.InterNetwork;
    }

    string ChooseIp()
    {
        List<string> locals = LocalIps();
        string saved = ReadIni("ip", "");
        if (ValidIp(saved) && locals.Contains(saved)) return saved;
        if (locals.Count > 0) return locals[0];
        if (ValidIp(saved)) return saved;
        return "127.0.0.1";
    }

    static string ChooseDir()
    {
        string d = ReadIni("dir", @"F:\Share\手机上传");
        if (string.IsNullOrWhiteSpace(d)) d = @"F:\Share\手机上传";
        return d;
    }

    void ChangeDir()
    {
        using (FolderBrowserDialog dlg = new FolderBrowserDialog())
        {
            dlg.Description = "选择手机上传文件的保存位置";
            dlg.ShowNewFolderButton = true;
            try { if (Directory.Exists(saveDir)) dlg.SelectedPath = saveDir; } catch { }
            if (dlg.ShowDialog(this) != DialogResult.OK) return;
            string v = dlg.SelectedPath;
            if (string.IsNullOrWhiteSpace(v)) return;
            try
            {
                Directory.CreateDirectory(v);
            }
            catch (Exception ex)
            {
                MessageBox.Show("无法使用这个文件夹：\r\n" + ex.Message, "手机传文件",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            saveDir = v;
            WriteIni("dir", saveDir);
            Invalidate();
        }
    }

    void ApplyIp()
    {
        url = "http://" + ip + ":" + Port;
        Bitmap old = qr;
        qr = BuildQr(url);
        qrPng = ToPng(qr);
        if (old != null) old.Dispose();
    }

    static Bitmap BuildQr(string text)
    {
        QRCodeGenerator gen = new QRCodeGenerator();
        QRCodeData data = gen.CreateQrCode(text, QRCodeGenerator.ECCLevel.M);
        QRCode code = new QRCode(data);
        return code.GetGraphic(12, Color.FromArgb(11, 18, 32), Color.White, true);
    }

    static byte[] ToPng(Image img)
    {
        using (MemoryStream ms = new MemoryStream())
        {
            img.Save(ms, ImageFormat.Png);
            return ms.ToArray();
        }
    }

    void ChangeIp()
    {
        using (IpDialog dlg = new IpDialog(LocalIps(), ip))
        {
            if (dlg.ShowDialog(this) != DialogResult.OK) return;
            string v = dlg.SelectedIp;
            if (!ValidIp(v))
            {
                MessageBox.Show("IP 格式不正确：" + v, "手机传文件", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            ip = v;
            ApplyIp();
            WriteIni("ip", ip);
            Invalidate();
        }
    }

    // ---------------- 绘制 ----------------

    static GraphicsPath Round(RectangleF r, float rad)
    {
        GraphicsPath p = new GraphicsPath();
        float d = rad * 2;
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }

    static Font UiFont(float px, FontStyle st)
    {
        return new Font("Microsoft YaHei UI", px, st, GraphicsUnit.Pixel);
    }

    static string Human(long n)
    {
        if (n < 1024) return n + " B";
        if (n < 1048576) return (n / 1024.0).ToString("0.0") + " KB";
        if (n < 1073741824) return (n / 1048576.0).ToString("0.0") + " MB";
        return (n / 1073741824.0).ToString("0.00") + " GB";
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        DarkTitle.Apply(Handle);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        g.ScaleTransform(scale, scale);

        float vw = Math.Max(420f, ClientSize.Width / scale);
        float vh = Math.Max(600f, ClientSize.Height / scale);
        using (SolidBrush bg = new SolidBrush(Color.FromArgb(7, 10, 16)))
        {
            g.FillRectangle(bg, 0, 0, vw, vh);
        }

        using (GraphicsPath glow = new GraphicsPath())
        {
            glow.AddEllipse(-160, -430, 740, 620);
            using (PathGradientBrush pg = new PathGradientBrush(glow))
            {
                pg.CenterColor = Color.FromArgb(30, 91, 140, 255);
                pg.SurroundColors = new Color[] { Color.FromArgb(0, 91, 140, 255) };
                g.FillPath(pg, glow);
            }
        }

        RectangleF logo = new RectangleF(24, 24, 44, 44);
        using (GraphicsPath lp = Round(logo, 13))
        using (SolidBrush lb = new SolidBrush(Color.FromArgb(91, 140, 255)))
        {
            g.FillPath(lb, lp);
        }
        using (Font lf = UiFont(23, FontStyle.Bold))
        using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
        {
            g.DrawString("↑", lf, BWhite, logo, sf);
        }

        using (Font tf = UiFont(19, FontStyle.Bold))
        {
            g.DrawString("手机传文件", tf, BText, 80, 25);
        }
        using (Font sub = UiFont(11.5f, FontStyle.Regular))
        {
            g.DrawString("同一 Wi-Fi 直连 · 原图不压缩", sub, BDim, 81, 51);
        }

        RectangleF card = new RectangleF(24, 96, 372, 300);
        using (GraphicsPath cp = Round(card, 18))
        using (SolidBrush cb = new SolidBrush(Color.White))
        {
            g.FillPath(cb, cp);
        }
        if (qr != null) g.DrawImage(qr, new RectangleF(92, 118, 236, 236));
        using (Font cap = UiFont(11, FontStyle.Regular))
        using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center })
        using (SolidBrush cdim = new SolidBrush(Color.FromArgb(135, 148, 170)))
        {
            g.DrawString("扫码打开上传页", cap, cdim, new RectangleF(24, 362, 372, 18), sf);
        }

        using (Font uf = UiFont(11.5f, FontStyle.Regular))
        {
            SizeF sz = g.MeasureString(url, uf);
            float uw = Math.Min(360f, sz.Width + 28);
            urlRect = new RectangleF((420 - uw) / 2f, 408, uw, 30);
            using (GraphicsPath up = Round(urlRect, 15))
            using (SolidBrush ub = new SolidBrush(Color.FromArgb(26, 91, 140, 255)))
            {
                g.FillPath(ub, up);
            }
            using (GraphicsPath up2 = Round(urlRect, 15))
            using (Pen pen = new Pen(Color.FromArgb(70, 91, 140, 255), 1f))
            {
                g.DrawPath(pen, up2);
            }
            using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
            {
                g.DrawString(url, uf, BAccent, urlRect, sf);
            }
        }

        string status = fileCount == 0
            ? "等待手机扫码…"
            : "已接收 " + fileCount + " 个文件 · " + Human(totalBytes);
        using (Font stf = UiFont(13, FontStyle.Bold))
        using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center })
        {
            g.DrawString(status, stf, fileCount == 0 ? BDim : BText, new RectangleF(24, 450, 372, 20), sf);
        }

        string sub2 = toast.Length > 0 ? toast : (lastName.Length > 0 ? "最近：" + lastName : "");
        if (sub2.Length > 0)
        {
            using (Font sf2 = UiFont(11, FontStyle.Regular))
            using (StringFormat fmt = new StringFormat
            {
                Alignment = StringAlignment.Center,
                Trimming = StringTrimming.EllipsisCharacter,
                FormatFlags = StringFormatFlags.NoWrap
            })
            using (SolidBrush sb = new SolidBrush(toast.Length > 0
                ? Color.FromArgb(61, 220, 151)
                : Color.FromArgb(115, 129, 154)))
            {
                g.DrawString(sub2, sf2, sb, new RectangleF(34, 474, 352, 16), fmt);
            }
        }

        btnOpen = new RectangleF(24, 500, 148, 44);
        using (GraphicsPath bp = Round(btnOpen, 13))
        using (SolidBrush bb = new SolidBrush(Color.FromArgb(91, 140, 255)))
        {
            g.FillPath(bb, bp);
        }
        using (Font bf = UiFont(13, FontStyle.Bold))
        using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
        {
            g.DrawString("打开文件夹", bf, BWhite, btnOpen, sf);
        }

        btnDir = new RectangleF(180, 500, 104, 44);
        DrawGhost(g, btnDir, "改路径");

        btnIp = new RectangleF(292, 500, 104, 44);
        DrawGhost(g, btnIp, "改 IP");

        using (Font ff = UiFont(10.5f, FontStyle.Regular))
        using (StringFormat sf = new StringFormat
        {
            Alignment = StringAlignment.Center,
            Trimming = StringTrimming.EllipsisCharacter,
            FormatFlags = StringFormatFlags.NoWrap
        })
        using (SolidBrush fb = new SolidBrush(Color.FromArgb(93, 104, 121)))
        {
            g.DrawString("保存到  " + saveDir, ff, fb, new RectangleF(24, 556, 372, 16), sf);
        }
    }

    void DrawGhost(Graphics g, RectangleF r, string text)
    {
        using (GraphicsPath path = Round(r, 13))
        using (SolidBrush fill = new SolidBrush(Color.FromArgb(18, 91, 140, 255)))
        {
            g.FillPath(fill, path);
        }
        using (GraphicsPath path2 = Round(r, 13))
        using (Pen pen = new Pen(Color.FromArgb(58, 91, 140, 255), 1f))
        {
            g.DrawPath(pen, path2);
        }
        using (Font bf = UiFont(12.5f, FontStyle.Bold))
        using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
        {
            g.DrawString(text, bf, BAccent, r, sf);
        }
    }


    protected override void OnMouseClick(MouseEventArgs e)
    {
        base.OnMouseClick(e);
        PointF pt = new PointF(e.X / scale, e.Y / scale);
        if (btnOpen.Contains(pt))
        {
            try { Process.Start("explorer.exe", "\"" + saveDir + "\""); } catch { }
            return;
        }
        if (btnDir.Contains(pt))
        {
            ChangeDir();
            return;
        }
        if (btnIp.Contains(pt))
        {
            ChangeIp();
            return;
        }
        if (urlRect.Contains(pt))
        {
            try { Clipboard.SetText(url); toast = "网址已复制"; toastUntil = DateTime.Now.AddSeconds(2); Invalidate(); }
            catch { }
        }
    }

    // ---------------- 服务 ----------------

    void Post(Action a)
    {
        try
        {
            if (!IsHandleCreated) return;
            BeginInvoke(a);
        }
        catch { }
    }

    void AcceptLoop()
    {
        while (true)
        {
            TcpClient c;
            try { c = listener.AcceptTcpClient(); }
            catch { break; }
            ThreadPool.QueueUserWorkItem(delegate(object o) { HandleClient((TcpClient)o); }, c);
        }
    }

    void HandleClient(TcpClient client)
    {
        try
        {
            using (client)
            using (NetworkStream s = client.GetStream())
            {
                string reqLine = ReadLine(s);
                if (string.IsNullOrEmpty(reqLine)) return;
                string[] parts = reqLine.Split(' ');
                if (parts.Length < 3) return;
                string method = parts[0];
                string path = parts[1];

                Dictionary<string, string> headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                string line;
                while ((line = ReadLine(s)) != null && line.Length > 0)
                {
                    int idx = line.IndexOf(':');
                    if (idx > 0) headers[line.Substring(0, idx).Trim()] = line.Substring(idx + 1).Trim();
                }

                string remote = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString();
                if (!Allowed(remote))
                {
                    Write(s, 403, "text/plain; charset=utf-8", "只允许局域网访问");
                    return;
                }

                if (method == "GET")
                {
                    if (path == "/" || path.StartsWith("/?") || path == "/index.html")
                        Write(s, 200, "text/html; charset=utf-8", page.Replace("{{URL}}", url).Replace("{{SAVE_DIR}}", saveDir));
                    else if (path == "/qr.png")
                        WriteBytes(s, 200, "image/png", qrPng);
                    else if (path == "/favicon.ico")
                        Write(s, 204, "text/plain", "");
                    else
                        Write(s, 404, "text/plain; charset=utf-8", "not found");
                    return;
                }

                if (method == "POST" && path.StartsWith("/upload"))
                {
                    int q = path.IndexOf("?name=");
                    string raw = q >= 0 ? path.Substring(q + 6) : "file";
                    string name = SafeName(Uri.UnescapeDataString(raw));

                    int len;
                    string cl;
                    if (!headers.TryGetValue("Content-Length", out cl) || !int.TryParse(cl, out len) || len <= 0)
                    {
                        Write(s, 400, "text/plain; charset=utf-8", "bad length");
                        return;
                    }

                    string dest = UniquePath(saveDir, name);
                    string tmp = dest + ".part";
                    int remaining = len;
                    bool ok = true;
                    using (FileStream fs = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None, 65536))
                    {
                        byte[] buf = new byte[65536];
                        while (remaining > 0)
                        {
                            int n = s.Read(buf, 0, Math.Min(buf.Length, remaining));
                            if (n <= 0) { ok = false; break; }
                            fs.Write(buf, 0, n);
                            remaining -= n;
                        }
                    }

                    if (!ok || remaining != 0)
                    {
                        try { File.Delete(tmp); } catch { }
                        Write(s, 500, "text/plain; charset=utf-8", "upload interrupted");
                        return;
                    }

                    try { File.Move(tmp, dest); }
                    catch
                    {
                        try { if (File.Exists(dest)) File.Delete(dest); File.Move(tmp, dest); } catch { }
                    }

                    string savedName = Path.GetFileName(dest);
                    long savedSize = new FileInfo(dest).Length;
                    Post(delegate
                    {
                        fileCount++;
                        totalBytes += savedSize;
                        lastName = savedName;
                        Invalidate();
                    });

                    Write(s, 200, "text/plain; charset=utf-8", "ok");
                    return;
                }

                Write(s, 404, "text/plain; charset=utf-8", "not found");
            }
        }
        catch { }
    }

    static string ReadLine(Stream s)
    {
        StringBuilder sb = new StringBuilder(128);
        int b;
        while ((b = s.ReadByte()) != -1)
        {
            if (b == '\n') return sb.ToString();
            if (b != '\r') sb.Append((char)b);
        }
        return sb.Length > 0 ? sb.ToString() : null;
    }

    static void Write(Stream s, int code, string ctype, string body)
    {
        WriteBytes(s, code, ctype, Encoding.UTF8.GetBytes(body ?? ""));
    }

    static void WriteBytes(Stream s, int code, string ctype, byte[] data)
    {
        if (data == null) data = new byte[0];
        string head = "HTTP/1.1 " + code + " " + (code == 200 ? "OK" : "ERR") + "\r\n" +
                      "Content-Type: " + ctype + "\r\n" +
                      "Content-Length: " + data.Length + "\r\n" +
                      "Cache-Control: no-store\r\n" +
                      "Connection: close\r\n\r\n";
        byte[] hb = Encoding.ASCII.GetBytes(head);
        s.Write(hb, 0, hb.Length);
        if (data.Length > 0) s.Write(data, 0, data.Length);
        s.Flush();
    }

    static bool Allowed(string ipStr)
    {
        if (ipStr == "::1") return true;
        if (ipStr.StartsWith("::ffff:", StringComparison.OrdinalIgnoreCase)) ipStr = ipStr.Substring(7);
        return ipStr.StartsWith("127.") || ipStr.StartsWith("192.168.") ||
               ipStr.StartsWith("10.") || ipStr.StartsWith("172.");
    }

    static string SafeName(string name)
    {
        if (string.IsNullOrWhiteSpace(name)) name = "file";
        name = name.Replace('\\', '_').Replace('/', '_');
        char[] bad = new char[] { '<', '>', ':', '"', '|', '?', '*', '\0', '\r', '\n', '\t' };
        StringBuilder sb = new StringBuilder(name.Length);
        foreach (char ch in name)
        {
            bool isBad = false;
            foreach (char b in bad) if (ch == b) { isBad = true; break; }
            if (!isBad && ch < 32) isBad = true;
            sb.Append(isBad ? '_' : ch);
        }
        name = sb.ToString().Trim(' ', '.');
        if (name.Length == 0) name = "file";
        string ext = Path.GetExtension(name);
        string stem = Path.GetFileNameWithoutExtension(name);
        if (stem.Length > 80) stem = stem.Substring(0, 80);
        return stem + ext;
    }

    static string UniquePath(string dir, string name)
    {
        string p = Path.Combine(dir, name);
        if (!File.Exists(p)) return p;
        string ext = Path.GetExtension(name);
        string stem = Path.GetFileNameWithoutExtension(name);
        for (int i = 1; i < 10000; i++)
        {
            p = Path.Combine(dir, stem + "_" + i + ext);
            if (!File.Exists(p)) return p;
        }
        return Path.Combine(dir, stem + "_" + DateTime.Now.Ticks + ext);
    }

    static string LoadPage()
    {
        try
        {
            using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("page.html"))
            {
                if (s != null)
                {
                    using (s)
                    using (StreamReader sr = new StreamReader(s, Encoding.UTF8))
                    {
                        return sr.ReadToEnd();
                    }
                }
            }
            string external = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "page.html");
            if (File.Exists(external)) return File.ReadAllText(external, Encoding.UTF8);
            return "<h1>page.html 缺失</h1>";
        }
        catch { return "<h1>页面加载失败</h1>"; }
    }}

class IpDialog : Form
{
    public string SelectedIp { get; private set; }
    ComboBox box;

    public IpDialog(List<string> ips, string current)
    {
        Text = "设置本机 IP";
        ClientSize = new Size(380, 186);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(15, 22, 38);
        ForeColor = Color.FromArgb(230, 236, 248);
        Font = new Font("Microsoft YaHei UI", 9f);

        Label lbl = new Label();
        lbl.Text = "选择或手动输入本机 IP（二维码会立即更新）：";
        lbl.ForeColor = Color.FromArgb(190, 205, 230);
        lbl.Bounds = new Rectangle(18, 16, 344, 20);

        box = new ComboBox();
        box.DropDownStyle = ComboBoxStyle.DropDown;
        box.Bounds = new Rectangle(18, 44, 344, 26);
        foreach (string s in ips) box.Items.Add(s);
        box.Text = current;
        box.BackColor = Color.FromArgb(22, 32, 52);
        box.ForeColor = Color.FromArgb(230, 236, 248);
        box.FlatStyle = FlatStyle.Flat;
        box.DrawMode = DrawMode.OwnerDrawFixed;
        box.ItemHeight = 22;
        box.DrawItem += delegate(object s, DrawItemEventArgs e)
        {
            bool sel = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
            using (SolidBrush b = new SolidBrush(sel ? Color.FromArgb(46, 72, 122) : Color.FromArgb(22, 32, 52)))
            {
                e.Graphics.FillRectangle(b, e.Bounds);
            }
            if (e.Index >= 0)
            {
                TextRenderer.DrawText(e.Graphics, box.Items[e.Index].ToString(), box.Font, e.Bounds,
                    Color.FromArgb(230, 236, 248), TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
            }
        };

        Label hint = new Label();
        hint.Text = ips.Count == 0 ? "未检测到可用的局域网地址" : "检测到 " + ips.Count + " 个地址";
        hint.ForeColor = Color.FromArgb(130, 148, 178);
        hint.Bounds = new Rectangle(18, 76, 344, 18);

        Button ok = new Button();
        ok.Text = "确定";
        ok.Bounds = new Rectangle(190, 118, 84, 30);
        ok.DialogResult = DialogResult.OK;
        ok.Click += delegate { SelectedIp = box.Text.Trim(); };

        Button cancel = new Button();
        cancel.Text = "取消";
        cancel.Bounds = new Rectangle(284, 118, 78, 30);
        cancel.DialogResult = DialogResult.Cancel;

        Controls.Add(lbl);
        Controls.Add(box);
        Controls.Add(hint);
        Controls.Add(ok);
        Controls.Add(cancel);
        AcceptButton = ok;
        CancelButton = cancel;
        SelectedIp = current;
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        DarkTitle.Apply(Handle);
    }
}

static class DarkTitle
{
    [System.Runtime.InteropServices.DllImport("dwmapi.dll")]
    static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);

    public static void Apply(IntPtr hwnd)
    {
        try
        {
            int on = 1;
            DwmSetWindowAttribute(hwnd, 20, ref on, 4);
            int caption = 0x002E1A10;
            DwmSetWindowAttribute(hwnd, 35, ref caption, 4);
            int border = 0x002E1A10;
            DwmSetWindowAttribute(hwnd, 34, ref border, 4);
            int text = 0x00FBEEE9;
            DwmSetWindowAttribute(hwnd, 36, ref text, 4);
        }
        catch { }
    }
}