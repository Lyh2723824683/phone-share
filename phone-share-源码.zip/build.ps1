﻿# 构建脚本：编译单文件 exe
# 用法: powershell -ExecutionPolicy Bypass -File .\build.ps1

$ErrorActionPreference = "Stop"

$root  = Split-Path -Parent $MyInvocation.MyCommand.Path
$src   = Join-Path $root "src"
$build = Join-Path $root "build"
$dist  = Join-Path $root "dist"

New-Item -ItemType Directory -Force -Path $build, $dist | Out-Null

# 1) 准备 QRCoder.dll
$qrcoder = Join-Path $build "QRCoder.dll"
if (-not (Test-Path $qrcoder)) {
    Write-Host "未找到 QRCoder.dll，正在从 NuGet 下载..." -ForegroundColor Cyan
    & (Join-Path $root "get-qrcoder.ps1") -OutFile $qrcoder
}

# 2) 定位编译器
$csc = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (-not (Test-Path $csc)) {
    $csc = Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe"
}
if (-not (Test-Path $csc)) {
    throw "未找到 csc.exe，请确认已安装 .NET Framework 4.x"
}

# 3) 编译（图标、清单、二维码库、网页资源全部嵌入）
$out = Join-Path $dist "手机传文件.exe"
Write-Host "编译中..." -ForegroundColor Cyan

& $csc /nologo /target:winexe /optimize+ /codepage:65001 `
    /win32icon:"$src\app_icon.ico" `
    /win32manifest:"$src\app.manifest" `
    /resource:"$qrcoder" `
    /resource:"$src\page.html" `
    /out:"$out" `
    /r:"$qrcoder" `
    /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll `
    "$src\PhoneUpload.cs"

if ($LASTEXITCODE -ne 0) { throw "编译失败（退出码 $LASTEXITCODE）" }

$size = [math]::Round((Get-Item $out).Length / 1KB)
Write-Host "完成: $out ($size KB)" -ForegroundColor Green
